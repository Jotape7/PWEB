let sexo = [45]
let opniao = [45]
let idade = [45]

let media = 0;
let homens = 0;
let mulheres = 0;
let pessimo = 0;
let qtde = 0;
let por;

for (i = 0; i < 45; i++) {
    sexo[i] = prompt("Digite seu sexo: ")
    if (sexo[i] === "M") {
        homens += 1;
    }
    if (sexo[i] === "F") {
        mulheres += 1
    }

    idade[i] = parseInt(prompt("Digite seu idade: "))

    opniao[i] = prompt("Digite seu opniao: ")
    if (opniao[i] == 4 || opniao[i] == 3) {
        qtde += 1
    }
    if (opniao[i] == 1) pessimo += 1

    media = media + idade[i];
}

por = (qtde / 45) * 100;
media = (media / 45);

alert("Média das idades: " + media.toFixed(2))

alert("Maior idade: " + Math.max.apply(null, idade))
alert("Menor idade: " + Math.min.apply(null, idade))
alert("Quantidade de pessoas que responderam Péssimo: " + pessimo)
alert("Porcentagem das pessoas que responderam ótimo e bom: " + por.toFixed(2) + "%")
alert("Mulheres: " + mulheres)
alert("Homens: " + homens)
