
do {
    opcaoUsuario = prompt("Digite pedra, papel ou tesoura:");

    opPc = Math.random();
    var escolhaPc

    if (opPc >= 0 && opPc < 0.35) escolhaPc = 'Pedra'
    if (opPc >= 0.35 && opPc < 0.65) escolhaPc = 'Papel'
    if (opPc >= 0.65 && opPc < 1) escolhaPc = 'Tesoura'

    if (opcaoUsuario == escolhaPc) alert('Empate!')

    if (opcaoUsuario == 'Pedra' && escolhaPc == 'Tesoura') alert('Usuario ganhou')

    if (opcaoUsuario == 'Papel' && escolhaPc == 'Pedra') alert('Usuario ganhou')

    if (opcaoUsuario == 'Tesoura' && escolhaPc == 'Papel') alert('Usuario ganhou')

    if (escolhaPc == 'Pedra' && opcaoUsuario == 'Tesoura') alert('PC ganhou')

    if (escolhaPc == 'Papel' && opcaoUsuario == 'Pedra') alert('PC ganhou')

    if (escolhaPc == 'Tesoura' && opcaoUsuario == 'Papel') alert('PC ganhou')
} while (opcaoUsuario != 0)
